extern void add_last_frags_to_sections(
    void);
extern void layout_addresses(
    void);
